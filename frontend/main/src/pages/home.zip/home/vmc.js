import React from "react";

function Vmc(){
    return(
        <section className="section bg-c-light border-top zx ba w">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 mb-5 text-center">
                           
                
                            <h2 className="main-heading z-4"> Vision , Mission and Values </h2>
                            <div className="underline mx-auto"></div></div>
                            {/* <div className='col-md-4 text-center'> */}
                                {/* <div class="card" style={{width: '18rem'}}> */}
                                <div className='col-md-4 text-center'>
                                <h3><b> Our Vision </b> </h3>
                                <p className="z-5">
                                To be a world-class enterprise that is passionate 
                           about the Standard of living of the general populace
                           and high returns to stakeholders
                                </p> </div>
  {/* <div className="card-body">
    <h5 className="card-title">Our Vision</h5>
    <p className="card-text">To be a world-class enterprise that is passionate 
                           about the Standard of living of the general populace
                           and high returns to stakeholders</p> */}
    {/* <a href="#" class="btn btn-primary">Go somewhere</a> */}
  {/* </div> */}
{/* </div> */}
                                {/* <h3> <b>our vision </b></h3>
                           
                           <p>To be a world-class enterprise that is passionate 
                           about the Standard of living of the general populace
                           and high returns to stakeholders</p> */}
                           {/* </div> */}
                          <div className='col-md-4 text-center'>
                                <h3><b> our mision </b> </h3>
                                <p className="z-5">
                                    Touch the lives of people by providing 
                                    their basic needs
                                </p> 
                                {/* <div class="card" style={{width: '18rem'}}> */}
  {/* <div className=""> */}
    {/* <h5 className="">Our Vision</h5>
    <p className="">To be a world-class enterprise that is passionate 
                           about the Standard of living of the general populace
                           and high returns to stakeholders</p> */}
    {/* <a href="#" class="btn btn-primary">Go somewhere</a> */}
  {/* </div> */}
{/* </div> */}
                          
                           </div>
                           <div className='col-md-4 text-center'>
                                <h3> <b>our core value</b></h3>
                           
                           <p className="z-5">-Customer service<br/>
                           -Ethics<br/> 
                           -Excellence<br/>
                        -Innovation  </p>

                           </div>
                    
                        </div>
                        </div>
                      
                    
                </section>
                
               
    )
}
export default  Vmc;
