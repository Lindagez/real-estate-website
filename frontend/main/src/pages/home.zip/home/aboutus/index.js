import React from 'react'
import "./index.css"
import aa from "../../../components/resources/images/b3.webp"

import Slis from './sliders'

const About1 = () => {
  return (
    // <div></div>
    <section >
    <div className='f  '> 

    
    <div className='i'>
      <div className='j'>
        <h1>About us</h1>
      </div></div></div>
      <div className=''> 
      <div className=''>
      
       
       
  
   
     
      {/* <div className='l  '>
      <div className='k'>
      <h2>Addis Hiwot
          <p>dscds</p> </h2></div> */}
      {/* </div> */}
     
  
      </div></div>
    

      <div id="blog-details" class="blog-details">

<div class="container" data-aos="fade-up" data-aos-delay="100">

  <div class="row g-5">

    <div class="col-lg-8">
      
    <div class="col-3 col-s-12">
              
            </div>
      <article class="article">

        <div class="post-img">
          <img src={aa} alt="" class="img-fluid"/>
        </div>

        <h2 class="title">Addis Hiwot Real Estate Development and Trading Plc</h2>

        {/* <div class="meta-top">
          <ul>
            <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="blog-details.html">John Doe</a></li>
            <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-details.html"><time datetime="2020-01-01">Jan 1, 2022</time></a></li>
            <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <a href="blog-details.html">12 Comments</a></li>
          </ul>
        </div> */}
<h2>The Company Overviews;</h2>
        <div class="content z-x">
          <p className='z-x'>
          {/* Addis Hiwot Real Estate Development and Trading Pvt. Limited Company is a sister Company of Eric Eriksson Business Plc. that has 17 years’ work experience in the real estate development industries since December 2005. This company has started its primary investment tasks in Adama Town in developing real estate. With this experience, Addis Hiwot Real Estate Development and Trading Pvt. Limited Company is recently upgraded itself to diversify its objectives to serve the basic necessity of community in alleviating housing problems found in Addis Ababa, and its surrounding communities of Addis Ababa.
This Company is, therefore, established under the name Addis Hiwot Real Estate development and Trading Plc. with registration capital of ETB 5,000,000.00 (Five Million ETB) in Addis Ababa, Ethiopia, in accordance with the commercial code of Ethiopia. Currently, it starts cooperatively with the enterprise and Government organizations in developing real estate development and then plans to participate in general trading activities throughout the country. 

          </p>
<h4>VISION AND MISSION</h4>
          <p>
          Vision: To be a world-class enterprise that is passionate about the standard of the lives of the general populace and high returns to stakeholders:
</p>
<p>Mission: Touch the lives of the communities thru providing their basic needs;</p>
          <h4>CORE VALUES</h4>
          <p></p>
          
<h4>THE SERVICES PROVIDED:</h4>
  

          <p className='mt-5'>
          Addis Hiwot Real Estate Development and Trading Pvt. Limited Company’s care business focus is to provide local, value-added products and services that meet the interest of the communities and alleviate the most basic problems in order to maximize the basic needs of the populace. Since its inception, the company is aimed to exercise phenomenal growth on account of the quality of its services. It works together to deliver the best products and service to our valuable customers and stakeholders.
In line to this, our company is a community-based development organization that provides services based on the need of the country, society and surrounding community. One of the services provided by Addis Hiwot Real Estate Development and Trading Plc. is to address the housing shortage, which is a bottleneck (an urgent) problem in the community, and to deal with issues related to housing, such as commercial centers for local services, recreational areas, etc. It is also to solve the social problems by building a park center, kindergarten, sports center, library, green garden space and so on.
To overcome this lack of housing, the main goal is to build a common houses or apartments. These common houses or apartments will have 15 to 25 floors, and four types houses as per stated below. For example, a three bedroom house apartment is sized up to 100 square meters and has three bedrooms, two bathrooms, a living room as well as kitchen including the common usage areas. However, when the work of constructing common shared houses or apartments is fully completed, it will be transferred to the members who are fully completed his /her contributions.
The building construction work of the houses or apartments will be transferred to the seller when it has been completed and fulfilled the following conditions. Such as an electric utilities and water lines have been installed; door and window work has been completed; and the kitchen and bathroom have been tiled. If the living room floor is made of tiles, standard, modern and comfortable to live in, then the finished houses will be transferred to all buyers (savers) as per agreement. One of the above houses (condominiums) will be given or transferable to the buyers who have fulfilled the required obligation according to the contract agreement made between buyers and sellers.
The total operating cost of the house or condominium will be estimated to be between 3.5 million and 6.5 million, based on the actual market conditions of the country's economy. However, if the country's economic situation and the price of construction materials rise more than expected and a difficult situation arises, the company can make a reasonable price revision by talking openly with the buyer who is saving to buy the house or apartment.

          </p> */}
Addis Hiwot Real Estate Development and Trading PLC. Ltd. is one of the leading real estate companies in Ethiopia, with a reputation for excellence in developing high quality residential and commercial properties. The company has been operating (working) in the Ethiopian real estate market seventeen years ago under the name of Eric Ericsson Business Pvt. Ltd., a sister company in Adama City, and has established itself, as a reliable and trustworthy partner for investors, homebuyers, and tenants alike.
Addis Hiwot was reorganized / reinitiated itself in 2015 by a group of experienced entrepreneurs with a vision to create a real estate development company that would be known for its commitment to quality, reliability, and customer satisfaction. The company has since grown to become one of the most respected real estate developers in the country, with a portfolio of successful projects that include residential buildings, commercial centers and office spaces. It is believed that this way and effort will make him successful.
The company's mission is to provide high quality real estate services that exceed the expectations of customers and contribute to the construction of urban infrastructure in Ethiopia. Addis Hiwot Real Estate is committed to providing affordable housing solutions to the growing population of the country. It is also a company with strong experience in delivering projects that meet the needs of both low and middle income buyers.
One of the key strengths of Addis Hiwot Real Estate is its team of experienced professionals, who bring a wealth of experienced expertise to a real estate project. The company brings members with extensive experience in management work, finance, project implementation and marketing to the real estate development and is supported by a well-skilled and talented group of architects, engineers and construction professionals as a part to achieve company Goal and Vision. Together, they work tirelessly to ensure and complete each project within the scheduled time frame, within budget and to the highest standards of quality. He is in a position to make tireless efforts to reach a level. 
Addis Hiwot Real Estate's commitment to quality is reflected in its approach to construction and design practices. For this, the company uses only the best materials and construction techniques, and works closely with architects and designers to create buildings that are both aesthetically pleasing and functional. As our company does this, each project is carefully planned and executed with a focus on maximizing space, optimizing energy efficiency and creating a comfortable and enjoyable living environment for residents.
Apart from its residential projects, Addis Hiwot Real Estate is also involved in developing commercial properties including office buildings, shopping malls and hotels. The company's commercial projects are designed to meet the needs of businesses of all sizes, which are available to operate in prime locations across the country.
In general, Addis Hiwot Real Estate Development and Trading Pvt. Ltd. is a company with a strong reputation for quality and reliability, and its commitment to customer satisfaction, combined with its experience in real estate development, has made it hard to become one of the most respected companies in the Ethiopian market. With a portfolio of successful projects and a strong team of professionals, Addis Hiwot Real Estate is well positioned to continue to grow and succeed in the coming years by solving societal problems and as the same time by contributing to the construction of urban infrastructure based on quality, integrity, excellence, and innovation in a sustainable way. Addis Hiwot strives hard for this result.

      </p>
          <div className='z-x'>
     {/* <h3 >Licence</h3></div> */}</div>

        <div >
       <Slis />
        </div>

          <h3>Prerequisites to own Houses (Apartments) are</h3>
          <p>
          •	Registration is expected by buyer for birr 5,000.00 according to the schedule issued by the real estate company.
         <br/> •	Completing the necessary documentations according to the requirements of the real estate company is evitable.

          </p>
          <p>
          Regarding the construction payment situation, based on a detailed price study,
           the housing contract agreement will be entered into by paying the first down
            payment of birr 50,000.00 (Fifty Thousand Birr) by depositing in a closed bank
             account for constructing house or Apartment. As for the remaining payment, 
             the owner of the house will be the beneficiary only if he/she saves 30% of the house's value in the bank's closed account within two to three years without interrupting the period and when the construction is completed.
          </p>
<p>
Concerning the payment of the remaining 70% of the price of the house, Addis Hiwot Real Estate (seller) will first facilitate the loan agreement with the bank and the buyer according to the loan payment schedule issued by the bank must complete the payment according to the loan agreement with the bank. Based on this, the Company will negotiate the details of the loan agreement with the bank and arrange it for the beneficiary of the shared houses (Apartments).

</p>
<h4>The types of the houses that the company plans to provide are</h4>
<div>
<table class="table">
  <thead>
    <tr>
      <th scope="col">s.no</th>
      <th scope="col">S.
No	The Type of the House to be Build (Scope of the Service)	House Area Allot	The Lowest Price
Investigation	Remarks
</th>
      <th scope="col">House Area Allot</th>
      <th scope="col">he Lowest Price
Investigation
</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>One-bedroom house apartment </td>
      <td>60-70 square meters </td>
      <td>3,500,000</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Two-bedrooms apartment </td>
      <td> 	80-90 square meters</td>
      <td>4,500,000</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>3	Three bedrooms apartment</td>
      <td>100-110 square meters </td>
      <td>5,500,000	 </td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Four bedrooms with especial size of
apartment (a little bit luxury)
</td>
      <td>	120-130 square meter 	6,500,000	 
</td>
      <td>6,500,000</td>
    </tr>
  </tbody>
</table>
</div>
<div>
  <h4>
  ክፍያ የሚደረግባቸው የባንክ ስምና ባንክ አካውንት ቁጥሮች
Types of Banks that Payment made and their Bank Account Numbers

  </h4>
</div>
<div>

<table class="table">
  <thead>
    <tr>
      <th scope="col">s.no</th>
      <th scope="col">የባንክ አገልግት አይነት
Types of Bank Service 
</th>
      <th scope="col">የኢትዮጶያ ንግድ ባንክ
CBE
</th>
      <th scope="col">ዳሽን ባንክ አ.ማ
Dashen Bank S.C
</th>
      <th scope="col">ኦሮሚያ ኅብረት ሥራ ባንክ
Cooperative Bank of Oromia
</th>
      <th scope="col">ብረሃን ባንክ አ.ማ
Berhan Bank S.C
</th>
      <th scope="col">አቢሲንያ ባንክ
Bank of Abyssinia
</th>
      <th scope="col">ሕብረት ባንክ አ.ማ
United (Hibret) Bank S.C
</th>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>የመመዝገቢያ ባንክ ሂሳብ ቁጥር
Registration Bank A/t 
</td>
      <td>1000524916634</td>
      <td>0141411591011</td>
      <td>1046500056038</td>
      <td> 2500040124795</td>
      <td>126969783</td>
      <td>	3771812686978016	
</td>
     
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>የግንባታ የዝግ የባንክ ሂሳብ ቁ.
Closed Bank A/t No
</td>
     
      <td>1000524919037</td>
      <td>0141411591021</td>
      <td>1046500056049</td>
      <td> 1300040010394</td>
      <td>126927339</td>
      <td>3770412685531018</td>

    </tr>
    

  </tbody>
</table>
</div>
        </div>
        
     </article></div></div></div></div></section>
   
 
   
 
 
  
  )
}

export default About1